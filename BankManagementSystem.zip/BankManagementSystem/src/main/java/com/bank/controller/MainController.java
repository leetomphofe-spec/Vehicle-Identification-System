package com.bank.controller;

import com.bank.model.Account;
import com.bank.model.Transaction;
import com.bank.service.BankService;
import com.bank.util.AlertUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class MainController {

    // ── Accounts Tab ──────────────────────────────────────────────────────────
    @FXML private TableView<Account>            accountsTable;
    @FXML private TableColumn<Account, Integer> colAccId;
    @FXML private TableColumn<Account, String>  colAccOwner;
    @FXML private TableColumn<Account, Double>  colAccBalance;
    @FXML private Label  lblAccountStatus;
    @FXML private Button btnEditAccount;
    @FXML private Button btnDeleteAccount;

    // ── Transactions Tab ──────────────────────────────────────────────────────
    @FXML private TableView<Transaction>            transactionsTable;
    @FXML private TableColumn<Transaction, Integer> colTxId;
    @FXML private TableColumn<Transaction, Integer> colTxFrom;
    @FXML private TableColumn<Transaction, Integer> colTxTo;
    @FXML private TableColumn<Transaction, String>  colTxType;
    @FXML private TableColumn<Transaction, Double>  colTxAmount;
    @FXML private TableColumn<Transaction, String>  colTxTime;

    // ── Transfer Tab ──────────────────────────────────────────────────────────
    @FXML private ComboBox<Account> cbTransferFrom;
    @FXML private ComboBox<Account> cbTransferTo;
    @FXML private TextField         tfTransferAmount;
    @FXML private Label             lblTransferStatus;
    @FXML private ComboBox<Account> cbDepWithAccount;
    @FXML private TextField         tfDepWithAmount;
    @FXML private Label             lblDepWithStatus;

    // ── Update Transaction Tab ────────────────────────────────────────────────
    @FXML private ComboBox<Transaction> cbUpdateTx;
    @FXML private Label                 lblCurrentAmount;
    @FXML private TextField             tfNewTxAmount;
    @FXML private Label                 lblUpdateTxStatus;

    private final BankService                bankService      = new BankService();
    private final ObservableList<Account>     accountsList     = FXCollections.observableArrayList();
    private final ObservableList<Transaction> transactionsList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        setupAccountsTable();
        setupTransactionsTable();
        loadAccounts();
        loadTransactions();
    }

    // ── Table Setup ───────────────────────────────────────────────────────────

    private void setupAccountsTable() {
        colAccId.setCellValueFactory(new PropertyValueFactory<>("accountId"));
        colAccOwner.setCellValueFactory(new PropertyValueFactory<>("ownerName"));
        colAccBalance.setCellValueFactory(new PropertyValueFactory<>("balance"));
        colAccBalance.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                setText(empty || v == null ? null : String.format("$%,.2f", v));
            }
        });
        accountsTable.setItems(accountsList);
    }

    private void setupTransactionsTable() {
        colTxId.setCellValueFactory(new PropertyValueFactory<>("transactionId"));
        colTxFrom.setCellValueFactory(new PropertyValueFactory<>("fromAccountId"));
        colTxTo.setCellValueFactory(new PropertyValueFactory<>("toAccountId"));
        colTxType.setCellValueFactory(new PropertyValueFactory<>("type"));
        colTxAmount.setCellValueFactory(new PropertyValueFactory<>("amount"));
        colTxAmount.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                setText(empty || v == null ? null : String.format("$%,.2f", v));
            }
        });
        colTxTime.setCellValueFactory(new PropertyValueFactory<>("timestamp"));
        transactionsTable.setItems(transactionsList);
    }

    // ── Data Loading ──────────────────────────────────────────────────────────

    private void loadAccounts() {
        Task<List<Account>> task = new Task<>() {
            @Override protected List<Account> call() throws SQLException {
                return bankService.getAllAccounts();
            }
        };
        task.setOnSucceeded(e -> {
            accountsList.setAll(task.getValue());
            refreshAccountCombos();
            lblAccountStatus.setText("Loaded " + accountsList.size() + " account(s).");
        });
        task.setOnFailed(e -> showError("Load Error", task.getException()));
        new Thread(task).start();
    }

    private void loadTransactions() {
        Task<List<Transaction>> task = new Task<>() {
            @Override protected List<Transaction> call() throws SQLException {
                return bankService.getAllTransactions();
            }
        };
        task.setOnSucceeded(e -> {
            transactionsList.setAll(task.getValue());
            refreshTxCombo();
        });
        task.setOnFailed(e -> showError("Load Error", task.getException()));
        new Thread(task).start();
    }

    private void refreshAccountCombos() {
        cbTransferFrom.setItems(FXCollections.observableArrayList(accountsList));
        cbTransferTo.setItems(FXCollections.observableArrayList(accountsList));
        cbDepWithAccount.setItems(FXCollections.observableArrayList(accountsList));
    }

    private void refreshTxCombo() {
        ObservableList<Transaction> transfers = FXCollections.observableArrayList(
                transactionsList.filtered(t -> "TRANSFER".equals(t.getType()))
        );
        cbUpdateTx.setItems(transfers);
        cbUpdateTx.setConverter(new javafx.util.StringConverter<>() {
            @Override public String toString(Transaction t) {
                return t == null ? "" : "TX#" + t.getTransactionId() + " — $" +
                        String.format("%.2f", t.getAmount()) +
                        " (Acc#" + t.getFromAccountId() + "→#" + t.getToAccountId() + ")";
            }
            @Override public Transaction fromString(String s) { return null; }
        });
    }

    // ── Account Dialog (pure Java — no FXML) ─────────────────────────────────

    private void showAccountDialog(Account existing) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle(existing == null ? "Add New Account" : "Edit Account");
        dialog.setHeaderText(existing == null ? "Enter account details:" : "Edit account details:");

        ButtonType saveBtn = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveBtn, ButtonType.CANCEL);

        // Form fields
        TextField tfName    = new TextField();
        TextField tfBalance = new TextField();
        Label     lblError  = new Label();
        lblError.setStyle("-fx-text-fill: red; -fx-font-size: 11px;");

        if (existing != null) {
            tfName.setText(existing.getOwnerName());
            tfBalance.setText(String.format("%.2f", existing.getBalance()));
        } else {
            tfName.setPromptText("Full name");
            tfBalance.setPromptText("0.00");
        }

        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(10);
        grid.setPadding(new Insets(10, 10, 0, 10));
        grid.add(new Label("Owner Name:"), 0, 0);
        grid.add(tfName, 1, 0);
        grid.add(new Label("Balance ($):"), 0, 1);
        grid.add(tfBalance, 1, 1);
        grid.add(lblError, 1, 2);

        tfName.setPrefWidth(230);
        tfBalance.setPrefWidth(230);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().setPrefWidth(400);

        // Disable Save button until fields valid
        javafx.scene.Node saveButton = dialog.getDialogPane().lookupButton(saveBtn);
        saveButton.setDisable(tfName.getText().isBlank());
        tfName.textProperty().addListener((obs, o, n) -> saveButton.setDisable(n.isBlank()));

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get().getButtonData() == ButtonBar.ButtonData.OK_DONE) {
            String name = tfName.getText().trim();
            if (name.isBlank()) { AlertUtil.showError("Validation", "Owner name is required."); return; }
            double balance;
            try {
                balance = Double.parseDouble(tfBalance.getText().trim());
                if (balance < 0) { AlertUtil.showError("Validation", "Balance cannot be negative."); return; }
            } catch (NumberFormatException ex) {
                AlertUtil.showError("Validation", "Balance must be a valid number.");
                return;
            }

            final String  finalName    = name;
            final double  finalBalance = balance;
            Task<Void> task = new Task<>() {
                @Override protected Void call() throws SQLException {
                    if (existing == null) bankService.createAccount(finalName, finalBalance);
                    else                  bankService.updateAccount(existing.getAccountId(), finalName, finalBalance);
                    return null;
                }
            };
            task.setOnSucceeded(e -> {
                loadAccounts();
                loadTransactions();
                lblAccountStatus.setText(existing == null ? "Account created." : "Account updated.");
            });
            task.setOnFailed(e -> showError("Save Error", task.getException()));
            new Thread(task).start();
        }
    }

    // ── Account CRUD Handlers ─────────────────────────────────────────────────

    @FXML private void handleAddAccount()  { showAccountDialog(null); }

    @FXML private void handleEditAccount() {
        Account selected = accountsTable.getSelectionModel().getSelectedItem();
        if (selected == null) { AlertUtil.showError("No Selection", "Please select an account to edit."); return; }
        showAccountDialog(selected);
    }

    @FXML private void handleDeleteAccount() {
        Account selected = accountsTable.getSelectionModel().getSelectedItem();
        if (selected == null) { AlertUtil.showError("No Selection", "Please select an account to delete."); return; }
        if (!AlertUtil.showConfirm("Confirm Delete",
                "Delete Account #" + selected.getAccountId() + " (" + selected.getOwnerName() + ")?\n" +
                "All associated transactions will also be deleted.")) return;

        Task<Void> task = new Task<>() {
            @Override protected Void call() throws SQLException {
                bankService.deleteAccount(selected.getAccountId());
                return null;
            }
        };
        task.setOnSucceeded(e -> { loadAccounts(); loadTransactions(); lblAccountStatus.setText("Account deleted."); });
        task.setOnFailed(e -> showError("Delete Error", task.getException()));
        new Thread(task).start();
    }

    @FXML private void handleRefresh()             { loadAccounts(); loadTransactions(); }
    @FXML private void handleRefreshTransactions() { loadTransactions(); }

    // ── Transfer Handlers ─────────────────────────────────────────────────────

    @FXML private void handleTransfer() {
        Account from   = cbTransferFrom.getValue();
        Account to     = cbTransferTo.getValue();
        String  amtStr = tfTransferAmount.getText().trim();
        if (from == null || to == null || amtStr.isBlank()) {
            setStatus(lblTransferStatus, "❌ Please fill in all fields.", false); return;
        }
        double amount;
        try { amount = Double.parseDouble(amtStr); }
        catch (NumberFormatException e) { setStatus(lblTransferStatus, "❌ Invalid amount.", false); return; }

        final double finalAmount = amount;
        Task<Void> task = new Task<>() {
            @Override protected Void call() throws Exception {
                bankService.transfer(from.getAccountId(), to.getAccountId(), finalAmount);
                return null;
            }
        };
        task.setOnSucceeded(e -> {
            setStatus(lblTransferStatus, "✅ Transfer of $" + String.format("%.2f", finalAmount) + " completed.", true);
            tfTransferAmount.clear();
            loadAccounts(); loadTransactions();
        });
        task.setOnFailed(e -> setStatus(lblTransferStatus, "❌ " + task.getException().getMessage(), false));
        new Thread(task).start();
    }

    @FXML private void handleClearTransfer() {
        cbTransferFrom.setValue(null); cbTransferTo.setValue(null);
        tfTransferAmount.clear(); lblTransferStatus.setText("");
    }

    @FXML private void handleDeposit()  { runDepWith("DEPOSIT"); }
    @FXML private void handleWithdraw() { runDepWith("WITHDRAW"); }

    private void runDepWith(String type) {
        Account account = cbDepWithAccount.getValue();
        String  amtStr  = tfDepWithAmount.getText().trim();
        if (account == null || amtStr.isBlank()) {
            setStatus(lblDepWithStatus, "❌ Please select account and enter amount.", false); return;
        }
        double amount;
        try { amount = Double.parseDouble(amtStr); }
        catch (NumberFormatException e) { setStatus(lblDepWithStatus, "❌ Invalid amount.", false); return; }

        final double finalAmount = amount;
        Task<Void> task = new Task<>() {
            @Override protected Void call() throws Exception {
                if ("DEPOSIT".equals(type)) bankService.deposit(account.getAccountId(), finalAmount);
                else                        bankService.withdraw(account.getAccountId(), finalAmount);
                return null;
            }
        };
        task.setOnSucceeded(e -> {
            setStatus(lblDepWithStatus, "✅ " + type + " of $" + String.format("%.2f", finalAmount) + " done.", true);
            tfDepWithAmount.clear();
            loadAccounts(); loadTransactions();
        });
        task.setOnFailed(e -> setStatus(lblDepWithStatus, "❌ " + task.getException().getMessage(), false));
        new Thread(task).start();
    }

    // ── Update Transaction Handlers ───────────────────────────────────────────

    @FXML private void handleTxSelected() {
        Transaction tx = cbUpdateTx.getValue();
        lblCurrentAmount.setText(tx != null ? "$" + String.format("%.2f", tx.getAmount()) : "—");
    }

    @FXML private void handleUpdateTransaction() {
        Transaction tx     = cbUpdateTx.getValue();
        String      amtStr = tfNewTxAmount.getText().trim();
        if (tx == null || amtStr.isBlank()) {
            setStatus(lblUpdateTxStatus, "❌ Please select a transaction and enter new amount.", false); return;
        }
        double newAmount;
        try { newAmount = Double.parseDouble(amtStr); }
        catch (NumberFormatException e) { setStatus(lblUpdateTxStatus, "❌ Invalid amount.", false); return; }

        final double finalNewAmount = newAmount;
        Task<Void> task = new Task<>() {
            @Override protected Void call() throws Exception {
                bankService.updateTransaction(tx.getTransactionId(), finalNewAmount);
                return null;
            }
        };
        task.setOnSucceeded(e -> {
            setStatus(lblUpdateTxStatus, "✅ TX#" + tx.getTransactionId() + " updated to $" +
                    String.format("%.2f", finalNewAmount) + ". Balances adjusted.", true);
            tfNewTxAmount.clear(); cbUpdateTx.setValue(null); lblCurrentAmount.setText("—");
            loadAccounts(); loadTransactions();
        });
        task.setOnFailed(e -> setStatus(lblUpdateTxStatus, "❌ " + task.getException().getMessage(), false));
        new Thread(task).start();
    }

    @FXML private void handleReloadTxList() { loadTransactions(); setStatus(lblUpdateTxStatus, "Reloaded.", true); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void setStatus(Label lbl, String msg, boolean success) {
        lbl.setStyle(success ? "-fx-text-fill: #388e3c;" : "-fx-text-fill: #c62828;");
        lbl.setText(msg);
    }

    private void showError(String title, Throwable e) {
        AlertUtil.showError(title, e != null ? e.getMessage() : "Unknown error");
    }
}
