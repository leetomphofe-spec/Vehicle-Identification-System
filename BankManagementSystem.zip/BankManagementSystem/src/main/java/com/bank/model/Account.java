package com.bank.model;

import javafx.beans.property.*;

public class Account {
    private final IntegerProperty accountId;
    private final StringProperty ownerName;
    private final DoubleProperty balance;

    public Account(int accountId, String ownerName, double balance) {
        this.accountId = new SimpleIntegerProperty(accountId);
        this.ownerName = new SimpleStringProperty(ownerName);
        this.balance = new SimpleDoubleProperty(balance);
    }

    // accountId
    public int getAccountId() { return accountId.get(); }
    public void setAccountId(int v) { accountId.set(v); }
    public IntegerProperty accountIdProperty() { return accountId; }

    // ownerName
    public String getOwnerName() { return ownerName.get(); }
    public void setOwnerName(String v) { ownerName.set(v); }
    public StringProperty ownerNameProperty() { return ownerName; }

    // balance
    public double getBalance() { return balance.get(); }
    public void setBalance(double v) { balance.set(v); }
    public DoubleProperty balanceProperty() { return balance; }

    @Override
    public String toString() {
        return "Account #" + getAccountId() + " - " + getOwnerName();
    }
}
