package com.bank.model;

import javafx.beans.property.*;

import java.time.LocalDateTime;

public class Transaction {
    private final IntegerProperty transactionId;
    private final IntegerProperty fromAccountId;
    private final IntegerProperty toAccountId;
    private final DoubleProperty amount;
    private final StringProperty type;
    private final StringProperty timestamp;

    public Transaction(int transactionId, int fromAccountId, int toAccountId,
                       double amount, String type, String timestamp) {
        this.transactionId = new SimpleIntegerProperty(transactionId);
        this.fromAccountId = new SimpleIntegerProperty(fromAccountId);
        this.toAccountId = new SimpleIntegerProperty(toAccountId);
        this.amount = new SimpleDoubleProperty(amount);
        this.type = new SimpleStringProperty(type);
        this.timestamp = new SimpleStringProperty(timestamp);
    }

    public int getTransactionId() { return transactionId.get(); }
    public void setTransactionId(int v) { transactionId.set(v); }
    public IntegerProperty transactionIdProperty() { return transactionId; }

    public int getFromAccountId() { return fromAccountId.get(); }
    public void setFromAccountId(int v) { fromAccountId.set(v); }
    public IntegerProperty fromAccountIdProperty() { return fromAccountId; }

    public int getToAccountId() { return toAccountId.get(); }
    public void setToAccountId(int v) { toAccountId.set(v); }
    public IntegerProperty toAccountIdProperty() { return toAccountId; }

    public double getAmount() { return amount.get(); }
    public void setAmount(double v) { amount.set(v); }
    public DoubleProperty amountProperty() { return amount; }

    public String getType() { return type.get(); }
    public void setType(String v) { type.set(v); }
    public StringProperty typeProperty() { return type; }

    public String getTimestamp() { return timestamp.get(); }
    public void setTimestamp(String v) { timestamp.set(v); }
    public StringProperty timestampProperty() { return timestamp; }
}
