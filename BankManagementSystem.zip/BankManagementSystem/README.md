# Bank Management System
### BIOP2210 – Object Oriented Programming II | Individual Take Home (15%)

---

## Overview

A JavaFX desktop application that manages bank customer accounts with full SQL transaction integrity.
Built following the **MVC architectural pattern** with **JavaFX + FXML**, **Java services/DAOs**, and **MySQL** via JDBC.

---

## Tech Stack

| Layer        | Technology                        |
|--------------|-----------------------------------|
| UI           | JavaFX 21 with FXML               |
| Language     | Java 17+                          |
| Architecture | MVC (Model-View-Controller)       |
| Database     | MySQL 8+                          |
| Build        | Maven                             |
| Concurrency  | JavaFX Task / background thread   |

---

## ⚙️ Database Setup

### Step 1 — Install MySQL
Make sure MySQL Server 8.x is installed and running on your machine.

### Step 2 — Configure credentials
Edit this file:
```
src/main/resources/com/bank/db.properties
```
```properties
db.host=localhost
db.port=3306
db.name=bank_db
db.username=root
db.password=your_password_here
```
> The database `bank_db` is **auto-created** on first run — you do NOT need to create it manually.

### Step 3 — Run the app
```bash
mvn clean javafx:run
```
Tables and sample data are created automatically on first launch.

---

## Project Structure

```
BankManagementSystem/
├── pom.xml
└── src/main/
    ├── java/
    │   ├── module-info.java
    │   └── com/bank/
    │       ├── MainApp.java
    │       ├── model/
    │       │   ├── Account.java
    │       │   └── Transaction.java
    │       ├── dao/
    │       │   ├── AccountDAO.java
    │       │   └── TransactionDAO.java
    │       ├── service/
    │       │   └── BankService.java         ← SQL transactions here
    │       ├── controller/
    │       │   ├── MainController.java
    │       │   └── AccountDialogController.java
    │       └── util/
    │           ├── DatabaseManager.java     ← MySQL connection + schema init
    │           └── AlertUtil.java
    └── resources/com/bank/
        ├── db.properties                   ← MySQL credentials ← EDIT THIS
        ├── fxml/
        │   ├── MainView.fxml
        │   └── AccountDialog.fxml
        └── css/
            └── styles.css
```

---

## Database Schema (MySQL)

```sql
CREATE DATABASE IF NOT EXISTS bank_db CHARACTER SET utf8mb4;

CREATE TABLE IF NOT EXISTS accounts (
    account_id  INT           AUTO_INCREMENT PRIMARY KEY,
    owner_name  VARCHAR(100)  NOT NULL,
    balance     DECIMAL(15,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS transactions (
    transaction_id  INT           AUTO_INCREMENT PRIMARY KEY,
    from_account_id INT,
    to_account_id   INT,
    amount          DECIMAL(15,2) NOT NULL,
    type            VARCHAR(20)   NOT NULL,   -- TRANSFER | DEPOSIT | WITHDRAW
    timestamp       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (from_account_id) REFERENCES accounts(account_id) ON DELETE CASCADE,
    FOREIGN KEY (to_account_id)   REFERENCES accounts(account_id) ON DELETE CASCADE
) ENGINE=InnoDB;
```

> `ENGINE=InnoDB` is required for foreign keys and transaction support in MySQL.

---

## Transaction Integrity Pattern

```java
Connection conn = DatabaseManager.getInstance().getConnection();
conn.setAutoCommit(false);
try {
    // ... debit Account A ...
    // ... credit Account B ...
    // ... insert transaction record ...
    conn.commit();
} catch (Exception e) {
    conn.rollback();   // money is NEVER lost
    throw e;
} finally {
    conn.setAutoCommit(true);
}
```

---

## Features

| Feature | Details |
|---------|---------|
| Create Account | Owner Name + Initial Balance |
| Read Accounts | JavaFX TableView, live refresh |
| Update Account | Edit name and balance |
| Delete Account | Cascades to all transactions |
| Transfer | Atomic debit+credit, rollback on insufficient funds |
| Deposit / Withdraw | Each wrapped in DB transaction |
| Update Transaction | Adjusts both balances atomically, rollback if negative |

---

*Submitted for BIOP2210 – Faculty of ICT, Y2S2*
