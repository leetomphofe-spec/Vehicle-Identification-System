package com.bank.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DatabaseManager {

    private static DatabaseManager instance;
    private Connection connection;

    private final String host;
    private final String port;
    private final String dbName;
    private final String username;
    private final String password;

    private DatabaseManager() {
        Properties props = new Properties();
        try (InputStream in = getClass().getResourceAsStream("/com/bank/db.properties")) {
            if (in == null) throw new RuntimeException("db.properties not found.");
            props.load(in);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load db.properties: " + e.getMessage(), e);
        }
        host     = props.getProperty("db.host",     "localhost");
        port     = props.getProperty("db.port",     "3306");
        dbName   = props.getProperty("db.name",     "bank_db");
        username = props.getProperty("db.username", "root");
        password = props.getProperty("db.password", "");
    }

    public static synchronized DatabaseManager getInstance() {
        if (instance == null) instance = new DatabaseManager();
        return instance;
    }

    public Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            // Connect directly to the database (after it's created)
            String url = "jdbc:mysql://" + host + ":" + port + "/" + dbName
                       + "?useSSL=false&characterEncoding=UTF-8";
            connection = DriverManager.getConnection(url, username, password);
            connection.setAutoCommit(true);
        }
        return connection;
    }

    public void initializeDatabase() throws SQLException {
        // Step 1: Connect WITHOUT database name to create it if missing
        String rootUrl = "jdbc:mysql://" + host + ":" + port + "?useSSL=false&characterEncoding=UTF-8";
        try (Connection rootConn = DriverManager.getConnection(rootUrl, username, password);
             Statement stmt = rootConn.createStatement()) {

            stmt.executeUpdate(
                "CREATE DATABASE IF NOT EXISTS `" + dbName + "` " +
                "DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci"
            );
        }

        // Step 2: Now connect to bank_db and create tables
        try (Statement stmt = getConnection().createStatement()) {

            stmt.execute(
                "CREATE TABLE IF NOT EXISTS accounts (" +
                "  account_id  INT           NOT NULL AUTO_INCREMENT PRIMARY KEY," +
                "  owner_name  VARCHAR(100)  NOT NULL," +
                "  balance     DECIMAL(15,2) NOT NULL DEFAULT 0.00" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8"
            );

            stmt.execute(
                "CREATE TABLE IF NOT EXISTS transactions (" +
                "  transaction_id  INT           NOT NULL AUTO_INCREMENT PRIMARY KEY," +
                "  from_account_id INT," +
                "  to_account_id   INT," +
                "  amount          DECIMAL(15,2) NOT NULL," +
                "  type            VARCHAR(20)   NOT NULL," +
                "  timestamp       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP," +
                "  FOREIGN KEY (from_account_id) REFERENCES accounts(account_id) ON DELETE CASCADE," +
                "  FOREIGN KEY (to_account_id)   REFERENCES accounts(account_id) ON DELETE CASCADE" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8"
            );

            // Seed sample data only if empty
            var rs = stmt.executeQuery("SELECT COUNT(*) FROM accounts");
            if (rs.next() && rs.getInt(1) == 0) {
                stmt.execute("INSERT INTO accounts (owner_name, balance) VALUES ('Alice Johnson', 5000.00)");
                stmt.execute("INSERT INTO accounts (owner_name, balance) VALUES ('Bob Smith',     3000.00)");
                stmt.execute("INSERT INTO accounts (owner_name, balance) VALUES ('Carol White',   7500.00)");
            }
            rs.close();
        }
    }

    public void closeConnection() {
        if (connection != null) {
            try { connection.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }
}
