package com.bank.service;

import com.bank.dao.AccountDAO;
import com.bank.dao.TransactionDAO;
import com.bank.model.Account;
import com.bank.model.Transaction;
import com.bank.util.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class BankService {

    private final AccountDAO accountDAO = new AccountDAO();
    private final TransactionDAO transactionDAO = new TransactionDAO();

    // ─── Account CRUD ────────────────────────────────────────────────────────

    public List<Account> getAllAccounts() throws SQLException {
        return accountDAO.getAllAccounts();
    }

    public void createAccount(String ownerName, double initialBalance) throws SQLException {
        if (ownerName == null || ownerName.isBlank())
            throw new IllegalArgumentException("Owner name cannot be empty.");
        if (initialBalance < 0)
            throw new IllegalArgumentException("Initial balance cannot be negative.");
        accountDAO.createAccount(ownerName.trim(), initialBalance);
    }

    public void updateAccount(int accountId, String ownerName, double balance) throws SQLException {
        if (ownerName == null || ownerName.isBlank())
            throw new IllegalArgumentException("Owner name cannot be empty.");
        if (balance < 0)
            throw new IllegalArgumentException("Balance cannot be negative.");
        accountDAO.updateAccount(accountId, ownerName.trim(), balance);
    }

    public void deleteAccount(int accountId) throws SQLException {
        accountDAO.deleteAccount(accountId);
    }

    // ─── Transactions ────────────────────────────────────────────────────────

    public List<Transaction> getAllTransactions() throws SQLException {
        return transactionDAO.getAllTransactions();
    }

    /**
     * Transfer: subtract from Account A, add to Account B.
     * Uses a DB transaction with rollback on any failure or insufficient funds.
     */
    public void transfer(int fromId, int toId, double amount) throws SQLException {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be positive.");
        if (fromId == toId) throw new IllegalArgumentException("Cannot transfer to the same account.");

        Connection conn = DatabaseManager.getInstance().getConnection();
        conn.setAutoCommit(false);
        try {
            // Lock and read sender balance
            double fromBalance = getBalanceForUpdate(conn, fromId);
            if (fromBalance < amount) {
                conn.rollback();
                throw new IllegalStateException("Insufficient funds in Account #" + fromId +
                        ". Available: $" + String.format("%.2f", fromBalance));
            }

            // Debit sender
            updateBalance(conn, fromId, fromBalance - amount);
            // Credit receiver
            double toBalance = getBalanceForUpdate(conn, toId);
            updateBalance(conn, toId, toBalance + amount);

            // Record transaction
            transactionDAO.insertTransaction(conn, fromId, toId, amount, "TRANSFER");

            conn.commit();
        } catch (Exception e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }
    }

    /**
     * Deposit: add amount to account.
     */
    public void deposit(int accountId, double amount) throws SQLException {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be positive.");

        Connection conn = DatabaseManager.getInstance().getConnection();
        conn.setAutoCommit(false);
        try {
            double bal = getBalanceForUpdate(conn, accountId);
            updateBalance(conn, accountId, bal + amount);
            transactionDAO.insertTransaction(conn, 0, accountId, amount, "DEPOSIT");
            conn.commit();
        } catch (Exception e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }
    }

    /**
     * Withdraw: subtract amount from account.
     */
    public void withdraw(int accountId, double amount) throws SQLException {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be positive.");

        Connection conn = DatabaseManager.getInstance().getConnection();
        conn.setAutoCommit(false);
        try {
            double bal = getBalanceForUpdate(conn, accountId);
            if (bal < amount) {
                conn.rollback();
                throw new IllegalStateException("Insufficient funds. Available: $" + String.format("%.2f", bal));
            }
            updateBalance(conn, accountId, bal - amount);
            transactionDAO.insertTransaction(conn, accountId, 0, amount, "WITHDRAW");
            conn.commit();
        } catch (Exception e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }
    }

    /**
     * Update Transaction: adjusts the transaction amount and corrects both account balances.
     * Rolls back entirely if either account would go negative.
     */
    public void updateTransaction(int txId, double newAmount) throws SQLException {
        if (newAmount <= 0) throw new IllegalArgumentException("Amount must be positive.");

        Connection conn = DatabaseManager.getInstance().getConnection();
        conn.setAutoCommit(false);
        try {
            Transaction tx = transactionDAO.getTransactionById(txId);
            if (tx == null) throw new IllegalArgumentException("Transaction #" + txId + " not found.");
            if (!"TRANSFER".equals(tx.getType()))
                throw new IllegalArgumentException("Only TRANSFER transactions can be updated this way.");

            double oldAmount = tx.getAmount();
            int fromId = tx.getFromAccountId();
            int toId = tx.getToAccountId();

            double fromBal = getBalanceForUpdate(conn, fromId);
            double toBal   = getBalanceForUpdate(conn, toId);

            // Reverse old amounts, apply new
            double newFromBal = fromBal + oldAmount - newAmount;
            double newToBal   = toBal  - oldAmount + newAmount;

            if (newFromBal < 0) {
                conn.rollback();
                throw new IllegalStateException("Account #" + fromId +
                        " would go negative after update. Rolled back.");
            }
            if (newToBal < 0) {
                conn.rollback();
                throw new IllegalStateException("Account #" + toId +
                        " would go negative after update. Rolled back.");
            }

            updateBalance(conn, fromId, newFromBal);
            updateBalance(conn, toId,   newToBal);
            transactionDAO.updateTransactionAmount(conn, txId, newAmount);

            conn.commit();
        } catch (Exception e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private double getBalanceForUpdate(Connection conn, int accountId) throws SQLException {
        String sql = "SELECT balance FROM accounts WHERE account_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, accountId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) throw new IllegalArgumentException("Account #" + accountId + " not found.");
                return rs.getDouble(1);
            }
        }
    }

    private void updateBalance(Connection conn, int accountId, double newBalance) throws SQLException {
        String sql = "UPDATE accounts SET balance = ? WHERE account_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDouble(1, newBalance);
            ps.setInt(2, accountId);
            ps.executeUpdate();
        }
    }
}
