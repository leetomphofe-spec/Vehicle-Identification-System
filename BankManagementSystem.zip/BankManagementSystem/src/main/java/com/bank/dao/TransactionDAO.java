package com.bank.dao;

import com.bank.model.Transaction;
import com.bank.util.DatabaseManager;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAO {

    public List<Transaction> getAllTransactions() throws SQLException {
        List<Transaction> list = new ArrayList<>();
        String sql = "SELECT transaction_id, from_account_id, to_account_id, amount, type, timestamp " +
                     "FROM transactions ORDER BY transaction_id DESC";
        try (Statement stmt = DatabaseManager.getInstance().getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Transaction(
                        rs.getInt("transaction_id"),
                        rs.getInt("from_account_id"),
                        rs.getInt("to_account_id"),
                        rs.getDouble("amount"),
                        rs.getString("type"),
                        rs.getString("timestamp")
                ));
            }
        }
        return list;
    }

    public Transaction getTransactionById(int txId) throws SQLException {
        String sql = "SELECT transaction_id, from_account_id, to_account_id, amount, type, timestamp " +
                     "FROM transactions WHERE transaction_id = ?";
        try (PreparedStatement ps = DatabaseManager.getInstance().getConnection().prepareStatement(sql)) {
            ps.setInt(1, txId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Transaction(
                            rs.getInt("transaction_id"),
                            rs.getInt("from_account_id"),
                            rs.getInt("to_account_id"),
                            rs.getDouble("amount"),
                            rs.getString("type"),
                            rs.getString("timestamp")
                    );
                }
            }
        }
        return null;
    }

    public void insertTransaction(Connection conn, int fromAccountId, int toAccountId,
                                  double amount, String type) throws SQLException {
        String sql = "INSERT INTO transactions (from_account_id, to_account_id, amount, type) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, fromAccountId);
            ps.setInt(2, toAccountId);
            ps.setDouble(3, amount);
            ps.setString(4, type);
            ps.executeUpdate();
        }
    }

    public void updateTransactionAmount(Connection conn, int txId, double newAmount) throws SQLException {
        String sql = "UPDATE transactions SET amount = ? WHERE transaction_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDouble(1, newAmount);
            ps.setInt(2, txId);
            ps.executeUpdate();
        }
    }
}
