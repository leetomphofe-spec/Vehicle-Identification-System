package com.bank.controller;

import com.bank.model.Account;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class AccountDialogController {

    @FXML private TextField tfOwnerName;
    @FXML private TextField tfBalance;
    @FXML private Label lblError;

    private Account existingAccount = null;

    /** Call before showing dialog to pre-fill for edit. */
    public void setAccount(Account account) {
        this.existingAccount = account;
        if (account != null) {
            tfOwnerName.setText(account.getOwnerName());
            tfBalance.setText(String.format("%.2f", account.getBalance()));
        }
    }

    public boolean isEditMode() {
        return existingAccount != null;
    }

    public String getOwnerName() {
        return tfOwnerName.getText().trim();
    }

    public double getBalance() {
        try {
            return Double.parseDouble(tfBalance.getText().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /** Returns true if validation passes. */
    public boolean validate() {
        lblError.setText("");
        if (tfOwnerName.getText().isBlank()) {
            lblError.setText("Owner name is required.");
            return false;
        }
        if (tfBalance.getText().isBlank()) {
            lblError.setText("Balance is required.");
            return false;
        }
        try {
            double bal = Double.parseDouble(tfBalance.getText().trim());
            if (bal < 0) {
                lblError.setText("Balance cannot be negative.");
                return false;
            }
        } catch (NumberFormatException e) {
            lblError.setText("Balance must be a valid number.");
            return false;
        }
        return true;
    }
}
