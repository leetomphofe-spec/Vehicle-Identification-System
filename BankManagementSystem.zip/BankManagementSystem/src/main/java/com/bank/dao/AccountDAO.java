package com.bank.dao;

import com.bank.model.Account;
import com.bank.util.DatabaseManager;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AccountDAO {

    public List<Account> getAllAccounts() throws SQLException {
        List<Account> accounts = new ArrayList<>();
        String sql = "SELECT account_id, owner_name, balance FROM accounts ORDER BY account_id";
        try (Statement stmt = DatabaseManager.getInstance().getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                accounts.add(new Account(
                        rs.getInt("account_id"),
                        rs.getString("owner_name"),
                        rs.getDouble("balance")
                ));
            }
        }
        return accounts;
    }

    public Account getAccountById(int accountId) throws SQLException {
        String sql = "SELECT account_id, owner_name, balance FROM accounts WHERE account_id = ?";
        try (PreparedStatement ps = DatabaseManager.getInstance().getConnection().prepareStatement(sql)) {
            ps.setInt(1, accountId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Account(rs.getInt("account_id"), rs.getString("owner_name"), rs.getDouble("balance"));
                }
            }
        }
        return null;
    }

    public void createAccount(String ownerName, double initialBalance) throws SQLException {
        String sql = "INSERT INTO accounts (owner_name, balance) VALUES (?, ?)";
        try (PreparedStatement ps = DatabaseManager.getInstance().getConnection().prepareStatement(sql)) {
            ps.setString(1, ownerName);
            ps.setDouble(2, initialBalance);
            ps.executeUpdate();
        }
    }

    public void updateAccount(int accountId, String ownerName, double balance) throws SQLException {
        String sql = "UPDATE accounts SET owner_name = ?, balance = ? WHERE account_id = ?";
        try (PreparedStatement ps = DatabaseManager.getInstance().getConnection().prepareStatement(sql)) {
            ps.setString(1, ownerName);
            ps.setDouble(2, balance);
            ps.setInt(3, accountId);
            ps.executeUpdate();
        }
    }

    public void deleteAccount(int accountId) throws SQLException {
        // Cascade delete handles transactions via FK
        String sql = "DELETE FROM accounts WHERE account_id = ?";
        try (PreparedStatement ps = DatabaseManager.getInstance().getConnection().prepareStatement(sql)) {
            ps.setInt(1, accountId);
            ps.executeUpdate();
        }
    }
}
